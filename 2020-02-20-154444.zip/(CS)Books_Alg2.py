import numpy as np
books_libs = {}
book_order = {}
library_books = {}
all_the_libraries = []
inFile = 'data/d_tough_choices.txt'
prob_list = []
t=[]


class Library(object):
    def __init__(self, library_key, set_time, books_per_day):
        self.key = library_key
        self.collection_of_submitted_books = []
        self.books = sorted(library_books[library_key][:],key=lambda x: book_order[x])
        self.books_per_day = books_per_day
        self.setup_time = set_time
#         self.prob = prob_list[library_key]
        self.score_value = 0
    def __str__(self):
        string_of_books = ''
        for s in self.collection_of_submitted_books:
            string_of_books += str(s) + ' '
        return f'{self.key} {len(self.collection_of_submitted_books)}\n'+string_of_books+'\n'
    def __repr__(self):
        return f'{self.score_value}'

    def books_submitted(self,days_left):
        num_books = (days_left-self.setup_time)*self.books_per_day
        if num_books <= 0:
            return []
        if num_books < len(self.books):
            self.collection_of_submitted_books = self.books[:num_books]
            return self.collection_of_submitted_books
        else:
            self.collection_of_submitted_books = self.books
            return self.collection_of_submitted_books
    def score(self,days_left):
        return sum(list(map(lambda x: book_order[x],self.books_submitted(days_left))))

with open(inFile,'r') as f:
    # num books, num libraries, total days
    t = list(map(int,f.readline().split()))
    prob_list = create_sorted_prob_list(size=t[1], dist=np.random.exponential, scale = 0.0001)
    order = f.readline().split()
    for i in range(t[0]):
        book_order[i] = int(order[i])
#     print(book_order)
    for i in range(t[1]):
        #num books, setup time, max books per day
        lib_info = list(map(int,f.readline().split()))

        lib_books = list(map(int,f.readline().split()))
#         print(lib_books)
        for book in lib_books:
            if library_books.get(i):
                library_books[i] = library_books[i] + [book]
            else:
                library_books[i] = [book]
            if books_libs.get(book):
                books_libs[book] = books_libs[book] + [i]
            else:
                books_libs[book] = [i]
#         print(i,t[2],lib_info)
        new_lib = Library(i,lib_info[1],lib_info[2])
        new_lib.score_value = new_lib.score(t[2])
        all_the_libraries.append(new_lib)
sorted_all_the_libraries = sorted(all_the_libraries,key=lambda lib: lib.score_value);all_the_libraries[-1:]
# library_books_copy = library_books.copy()
# books_libs_copy = books_libs.copy()
# sorted_copy = sorted_all_the_libraries[:]
indicies = [i for i in range(len(sorted_all_the_libraries))]
# prob_copy = prob_list[:]

# print(len(sorted_copy),len(prob_copy))
factor = 0.5
selected_libs = []
time_remaining = t[2]
#IM ALL IN YOUR LOOP
while time_remaining > 1 and not all(prob_list == 0):
    #choose with probability (with index)
#     print(len())
    prob_list = prob_list/sum(prob_list)
    index = np.random.choice(indicies,p=prob_list)
    choice = sorted_all_the_libraries[index]
    prob_list[index] = 0
    if choice.setup_time < time_remaining:
        choice.score_value = choice.score(time_remaining)
        selected_libs.append(choice)
        for book in choice.books_submitted(time_remaining):
            for lib_index in books_libs[book]:
#                 print(i, book, library_books[lib_index])
                if lib_index != index:
                    all_the_libraries[lib_index].books.remove(book)
                prob_list[lib_index]*=factor #does not look at points of book
        time_remaining -= choice.setup_time

with open(sys.argv[2], "w") as output_file:
    output_file.write(f'{len(selected_libs)}\n')
    for cur_lib_to_print in selected_libs:
        output_file.write(str(cur_lib_to_print))